package com.sivamani.mylifemanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mylife_data", MODE_PRIVATE) }
    private var language = "en"
    private var dark = false
    private var page = "home"
    private val green = Color.rgb(23,107,88)
    private val white = Color.WHITE
    private val ink get() = if (dark) Color.rgb(239,246,241) else Color.rgb(23,37,33)
    private val bg get() = if (dark) Color.rgb(17,25,22) else Color.rgb(243,246,244)
    private val cardBg get() = if (dark) Color.rgb(27,38,33) else Color.WHITE
    private val muted get() = if (dark) Color.rgb(165,180,171) else Color.rgb(100,115,109)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout

    private fun t(en: String, ta: String) = if (language == "ta") ta else en
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun currency(amount: Double): String =
        NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(amount)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        language = prefs.getString("language", "en") ?: "en"
        dark = prefs.getBoolean("dark", false)
        showPage("home")
    }

    private fun readArray(key: String): JSONArray = try {
        JSONArray(prefs.getString(key, "[]"))
    } catch (_: Exception) { JSONArray() }

    private fun writeArray(key: String, array: JSONArray) {
        prefs.edit().putString(key, array.toString()).apply()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 16f, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(ink)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(7), dp(4), dp(7))
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        setTextColor(ink)
        setHintTextColor(muted)
        textSize = 16f
        setSingleLine(true)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        backgroundTintList = android.content.res.ColorStateList.valueOf(green)
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(12), dp(16), dp(16))
    }

    private fun addLabel(parent: LinearLayout, label: String, size: Float = 20f, bold: Boolean = true) {
        parent.addView(text(label, size, bold))
    }

    private fun showPage(target: String) {
        page = target
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(green)
        }
        header.addView(TextView(this).apply {
            text = "🌿 MyLifeManager"
            textSize = 23f
            setTextColor(white)
            setTypeface(typeface, Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = t("Your personal life, organised", "உங்கள் வாழ்க்கையை ஒழுங்குபடுத்துங்கள்")
            textSize = 13f
            setTextColor(white)
        })
        val toggles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toggles.addView(Button(this@MainActivity).apply {
            text = if (language == "en") "தமிழ்" else "English"
            isAllCaps = false
            setOnClickListener {
                language = if (language == "en") "ta" else "en"
                prefs.edit().putString("language", language).apply()
                showPage(page)
            }
        })
        toggles.addView(Button(this@MainActivity).apply {
            text = if (dark) "☀ Light" else "🌙 Dark"
            isAllCaps = false
            setOnClickListener {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
                showPage(page)
            }
        })
        header.addView(toggles)
        root.addView(header)

        val scroll = ScrollView(this)
        content = column()
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(cardBg)
            gravity = Gravity.CENTER
        }
        listOf(
            "home" to t("Home", "முகப்பு"),
            "expenses" to t("Expenses", "செலவுகள்"),
            "todo" to t("To-Do", "பணிகள்"),
            "days" to t("Important Days", "முக்கிய நாட்கள்"),
            "calendar" to t("Calendar", "காலண்டர்")
        ).forEach { (id, label) ->
            nav.addView(Button(this).apply {
                text = label
                textSize = 10f
                isAllCaps = false
                setPadding(dp(2), dp(5), dp(2), dp(5))
                setOnClickListener { showPage(id) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
        when (target) {
            "home" -> home()
            "expenses" -> expensesPage()
            "todo" -> todoPage()
            "days" -> daysPage()
            "calendar" -> calendarPage()
        }
    }

    private fun home() {
        addLabel(content, t("Today at a glance", "இன்றைய சுருக்கம்"))
        val ex = readArray("entries")
        var spent = 0.0
        var income = 0.0
        val month = today().substring(0, 7)
        for (i in 0 until ex.length()) {
            val item = ex.optJSONObject(i) ?: continue
            val amount = item.optDouble("amount", 0.0)
            if (item.optString("date").startsWith(month)) {
                if (item.optString("type") == "income") income += amount else spent += amount
            }
        }
        val tasks = readArray("tasks")
        var remaining = 0
        for (i in 0 until tasks.length()) if (!tasks.optJSONObject(i).optBoolean("done")) remaining++
        addLabel(content, t("Spent this month: ", "இந்த மாதச் செலவு: ") + currency(spent), 18f)
        content.addView(text(t("Income recorded: ", "பதிவு செய்த வரவு: ") + currency(income)))
        content.addView(text(t("Tasks remaining: ", "மீதமுள்ள பணிகள்: ") + remaining))
        addLabel(content, t("Quick access", "விரைவு அணுகல்"))
        content.addView(button("💰 " + t("Add expense / income", "வரவு / செலவு சேர்")) { showPage("expenses") })
        content.addView(button("✅ " + t("Add a to-do task", "பணி சேர்")) { showPage("todo") })
        content.addView(button("🎉 " + t("Save an important day", "முக்கிய நாளைச் சேமி")) { showPage("days") })
        content.addView(button("🗓️ " + t("Open calendar", "காலண்டரைத் திற")) { showPage("calendar") })
        addLabel(content, t("Upcoming important days", "வரவிருக்கும் முக்கிய நாட்கள்"))
        val ds = readArray("days")
        var shown = 0
        for (i in 0 until ds.length()) {
            val d = ds.optJSONObject(i) ?: continue
            if (d.optString("date") >= today()) {
                content.addView(text("🎉 ${d.optString("name")} — ${d.optString("date")}", 15f))
                shown++
            }
        }
        if (shown == 0) content.addView(text(t("No saved dates yet.", "முக்கிய நாட்கள் இன்னும் இல்லை."), 14f))
        content.addView(text(t("Saved privately on this phone.", "இந்த மொபைலில் உள்ளூரில் சேமிக்கப்படும்."), 12f))
    }

    private fun expensesPage() {
        addLabel(content, t("Expenses & Income", "வரவு மற்றும் செலவு"))
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf(t("Expense", "செலவு"), t("Income", "வரவு")))
        val amount = field(t("Amount ₹", "தொகை ₹"))
        amount.inputType = 8194
        val category = field(t("Category (Food, Travel...)", "வகை (உணவு, பயணம்...)"))
        val date = field(t("Date YYYY-MM-DD", "தேதி YYYY-MM-DD"))
        date.setText(today())
        val note = field(t("Note (optional)", "குறிப்பு (விருப்பம்)"))
        content.addView(type); content.addView(amount); content.addView(category); content.addView(date); content.addView(note)
        content.addView(button(t("+ Add entry", "+ பதிவு சேர்")) {
            val n = amount.text.toString().toDoubleOrNull()
            if (n == null || n <= 0 || category.text.isBlank() || date.text.length < 10) {
                toast(t("Enter a valid amount, category and date.", "சரியான தொகை, வகை, தேதியை உள்ளிடவும்.")); return@button
            }
            val a = readArray("entries")
            a.put(JSONObject().put("type", if (type.selectedItemPosition == 1) "income" else "expense")
                .put("amount", n).put("category", category.text.toString())
                .put("date", date.text.toString()).put("note", note.text.toString()))
            writeArray("entries", a)
            showPage("expenses")
            toast(t("Saved on this phone.", "மொபைலில் சேமிக்கப்பட்டது."))
        })
        addLabel(content, t("Recent entries", "சமீபத்திய பதிவுகள்"))
        val a = readArray("entries")
        if (a.length() == 0) content.addView(text(t("No entries yet.", "இன்னும் பதிவுகள் இல்லை."), 14f))
        for (i in a.length() - 1 downTo 0) {
            val e = a.optJSONObject(i) ?: continue
            content.addView(text("${if (e.optString("type") == "income") "🟢" else "🔴"} ${e.optString("category")} · ${currency(e.optDouble("amount"))}\n${e.optString("date")} ${e.optString("note")}", 15f))
        }
    }

    private fun todoPage() {
        addLabel(content, t("To-Do activities", "செய்ய வேண்டிய செயல்கள்"))
        val name = field(t("What do you need to do?", "என்ன செய்ய வேண்டும்?"))
        val date = field(t("Due date YYYY-MM-DD", "கடைசி தேதி YYYY-MM-DD"))
        date.setText(today())
        val priority = Spinner(this)
        priority.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf(t("Normal priority", "சாதாரண முன்னுரிமை"), t("High priority", "அதிக முன்னுரிமை"), t("Low priority", "குறைந்த முன்னுரிமை")))
        content.addView(name); content.addView(date); content.addView(priority)
        content.addView(button(t("+ Add task", "+ பணி சேர்")) {
            if (name.text.isBlank() || date.text.length < 10) {
                toast(t("Enter a task and due date.", "பணி மற்றும் தேதியை உள்ளிடவும்.")); return@button
            }
            val a = readArray("tasks")
            a.put(JSONObject().put("name", name.text.toString()).put("date", date.text.toString())
                .put("priority", priority.selectedItem.toString()).put("done", false))
            writeArray("tasks", a); showPage("todo")
        })
        addLabel(content, t("Your tasks", "உங்கள் பணிகள்"))
        val a = readArray("tasks")
        if (a.length() == 0) content.addView(text(t("No tasks yet.", "இன்னும் பணிகள் இல்லை."), 14f))
        for (i in 0 until a.length()) {
            val task = a.optJSONObject(i) ?: continue
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val check = CheckBox(this).apply {
                text = "${task.optString("name")}\n${task.optString("date")} · ${task.optString("priority")}"
                setTextColor(ink); isChecked = task.optBoolean("done")
                setOnCheckedChangeListener { _, checked ->
                    task.put("done", checked); writeArray("tasks", a)
                }
            }
            row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("✕") {
                val new = JSONArray()
                for (j in 0 until a.length()) if (j != i) new.put(a.optJSONObject(j))
                writeArray("tasks", new); showPage("todo")
            })
            content.addView(row)
        }
    }

    private fun daysPage() {
        addLabel(content, t("Important Days", "முக்கிய நாட்கள்"))
        val name = field(t("Birthday, anniversary...", "பிறந்தநாள், திருமண நாள்..."))
        val date = field(t("Date YYYY-MM-DD", "தேதி YYYY-MM-DD"))
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf(t("Birthday", "பிறந்தநாள்"), t("Anniversary", "திருமண நாள்"), t("Festival", "பண்டிகை"), t("Other", "மற்றவை")))
        content.addView(name); content.addView(date); content.addView(type)
        content.addView(button(t("+ Save important day", "+ முக்கிய நாளைச் சேமி")) {
            if (name.text.isBlank() || date.text.length < 10) {
                toast(t("Enter a name and date.", "பெயர் மற்றும் தேதியை உள்ளிடவும்.")); return@button
            }
            val a = readArray("days")
            a.put(JSONObject().put("name", name.text.toString()).put("date", date.text.toString()).put("type", type.selectedItem.toString()))
            writeArray("days", a); showPage("days")
        })
        content.addView(text(t("Saved dates (automatic notifications will be added later).", "சேமித்த நாட்கள் (தானியங்கி அறிவிப்புகள் பின்னர் சேர்க்கப்படும்)."), 13f))
        val a = readArray("days")
        if (a.length() == 0) content.addView(text(t("No important days saved.", "முக்கிய நாட்கள் சேமிக்கப்படவில்லை."), 14f))
        for (i in 0 until a.length()) {
            val d = a.optJSONObject(i) ?: continue
            content.addView(text("🎉 ${d.optString("name")}\n${d.optString("date")} · ${d.optString("type")}", 15f))
        }
    }

    private fun calendarPage() {
        addLabel(content, t("Calendar / நாட்காட்டி", "காலண்டர் / Calendar"))
        content.addView(text(SimpleDateFormat("MMMM yyyy", if (language == "ta") Locale("ta", "IN") else Locale.ENGLISH).format(Date()), 22f, true))
        content.addView(text(t("Tamil calendar data will be added in a later version. This prototype currently shows today's Gregorian date.", "தமிழ் காலண்டர் தரவு அடுத்த பதிப்பில் சேர்க்கப்படும். இப்போது ஆங்கில/Gregorian தேதியைக் காட்டுகிறது."), 14f))
        content.addView(text(t("Today: ", "இன்று: ") + today(), 18f, true))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
