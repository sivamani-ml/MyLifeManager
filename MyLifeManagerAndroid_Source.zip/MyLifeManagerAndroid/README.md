# MyLifeManager Android source project

A beginner-friendly native Android Kotlin starter project for personal expense tracking, to-do tasks, important days, Tamil/English UI labels, light/dark mode, and local offline storage.

## Important status
- This is Android source code, not a prebuilt APK.
- It has not been compiled or tested in this environment.
- The calendar currently shows the Gregorian date; accurate Tamil calendar data and scheduled notifications are not yet implemented.
- Data is stored locally in Android SharedPreferences as JSON. It is not encrypted or backed up.

## Build
Open this project in Android Studio, allow Gradle sync, then use Build > Build Bundle(s) / APK(s) > Build APK(s).
Requires Android SDK platform 35 and a compatible JDK/Gradle setup.

## Phone-only users
This source ZIP alone cannot install as an app. A build environment or trusted cloud Android build service is still needed to compile an APK. Do not install unknown APKs or disable Play Protect.
